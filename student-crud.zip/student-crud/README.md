# Student CRUD API — Spring Boot + eXist-DB
================================================

## Project Structure
```
student-crud/
├── pom.xml
└── src/main/
    ├── java/com/existdb/student/
    │   ├── StudentCrudApplication.java   ← Main class
    │   ├── controller/
    │   │   └── StudentController.java    ← REST endpoints
    │   ├── model/
    │   │   └── Student.java             ← Data model
    │   ├── service/
    │   │   └── StudentService.java      ← Business logic
    │   ├── repository/
    │   │   └── StudentRepository.java   ← eXist-DB operations
    │   └── config/
    │       └── ExistDbConfig.java       ← DB connection
    └── resources/
        └── application.properties       ← Settings
```

## Prerequisites
- Java 22
- Maven installed
- eXist-DB 6.4.1 running on localhost:8080

## STEP 1 — Open in VS Code
```
code student-crud
```

## STEP 2 — Make sure eXist-DB is running
```
cd C:\eXist-db
bin\startup.bat
```

## STEP 3 — Run the Spring Boot App
```
cd student-crud
mvn spring-boot:run
```

## STEP 4 — Test the API

### Health Check
GET http://localhost:8081/api/students/health

### CREATE a Student
POST http://localhost:8081/api/students
Content-Type: application/json
{
  "id": "1",
  "name": "Rithesh",
  "department": "Computer Science",
  "grade": "A"
}

### READ All Students
GET http://localhost:8081/api/students

### READ One Student
GET http://localhost:8081/api/students/1

### UPDATE a Student
PUT http://localhost:8081/api/students/1
Content-Type: application/json
{
  "name": "Rithesh Kumar",
  "department": "Information Technology",
  "grade": "A+"
}

### DELETE a Student
DELETE http://localhost:8081/api/students/1

## Test with curl (CMD)
```
# CREATE
curl -X POST http://localhost:8081/api/students ^
  -H "Content-Type: application/json" ^
  -d "{\"id\":\"1\",\"name\":\"Rithesh\",\"department\":\"CS\",\"grade\":\"A\"}"

# READ ALL
curl http://localhost:8081/api/students

# READ ONE
curl http://localhost:8081/api/students/1

# UPDATE
curl -X PUT http://localhost:8081/api/students/1 ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Rithesh K\",\"department\":\"IT\",\"grade\":\"A+\"}"

# DELETE
curl -X DELETE http://localhost:8081/api/students/1
```

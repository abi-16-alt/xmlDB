package com.existdb.student.service;

import com.existdb.student.model.Student;
import com.existdb.student.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    // CREATE
    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }

    // READ ALL
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    // READ BY ID
    public Optional<Student> getStudentById(String id) {
        return studentRepository.findById(id);
    }

    // UPDATE
    public Optional<Student> updateStudent(String id, Student student) {
        return studentRepository.update(id, student);
    }

    // DELETE
    public boolean deleteStudent(String id) {
        return studentRepository.deleteById(id);
    }
}

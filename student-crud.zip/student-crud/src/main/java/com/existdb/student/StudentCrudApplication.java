package com.existdb.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentCrudApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentCrudApplication.class, args);
        System.out.println("\n========================================");
        System.out.println("  Student CRUD API is Running!");
        System.out.println("  URL: http://localhost:8081/api/students");
        System.out.println("========================================\n");
    }
}

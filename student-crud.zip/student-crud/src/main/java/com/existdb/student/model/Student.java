package com.existdb.student.model;

public class Student {
    private String id;
    private String name;
    private String department;
    private String grade;

    // Default constructor
    public Student() {}

    // Parameterized constructor
    public Student(String id, String name, String department, String grade) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.grade = grade;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    // Convert Student to XML string
    public String toXml() {
        return "<student>" +
               "<id>" + id + "</id>" +
               "<name>" + name + "</name>" +
               "<department>" + department + "</department>" +
               "<grade>" + grade + "</grade>" +
               "</student>";
    }

    @Override
    public String toString() {
        return "Student{id='" + id + "', name='" + name + 
               "', department='" + department + "', grade='" + grade + "'}";
    }
}

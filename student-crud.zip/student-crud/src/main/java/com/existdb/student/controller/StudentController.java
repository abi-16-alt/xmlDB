package com.existdb.student.controller;

import com.existdb.student.model.Student;
import com.existdb.student.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = "*")
public class StudentController {

    @Autowired
    private StudentService studentService;

    // =============================================
    // CREATE — POST /api/students
    // =============================================
    @PostMapping
    public ResponseEntity<?> createStudent(@RequestBody Student student) {
        try {
            if (student.getId() == null || student.getId().isBlank()) {
                return ResponseEntity.badRequest()
                    .body("❌ Student ID is required!");
            }
            Student created = studentService.createStudent(student);
            return ResponseEntity.status(HttpStatus.CREATED).body(created);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("❌ Error creating student: " + e.getMessage());
        }
    }

    // =============================================
    // READ ALL — GET /api/students
    // =============================================
    @GetMapping
    public ResponseEntity<List<Student>> getAllStudents() {
        List<Student> students = studentService.getAllStudents();
        return ResponseEntity.ok(students);
    }

    // =============================================
    // READ BY ID — GET /api/students/{id}
    // =============================================
    @GetMapping("/{id}")
    public ResponseEntity<?> getStudentById(@PathVariable String id) {
        Optional<Student> student = studentService.getStudentById(id);
        if (student.isPresent()) {
            return ResponseEntity.ok(student.get());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
            .body("❌ Student not found with ID: " + id);
    }

    // =============================================
    // UPDATE — PUT /api/students/{id}
    // =============================================
    @PutMapping("/{id}")
    public ResponseEntity<?> updateStudent(
            @PathVariable String id,
            @RequestBody Student student) {
        Optional<Student> updated = studentService.updateStudent(id, student);
        if (updated.isPresent()) {
            return ResponseEntity.ok(updated.get());
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
            .body("❌ Student not found with ID: " + id);
    }

    // =============================================
    // DELETE — DELETE /api/students/{id}
    // =============================================
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteStudent(@PathVariable String id) {
        boolean deleted = studentService.deleteStudent(id);
        if (deleted) {
            return ResponseEntity.ok("✅ Student " + id + " deleted successfully!");
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
            .body("❌ Student not found with ID: " + id);
    }

    // =============================================
    // HEALTH CHECK — GET /api/students/health
    // =============================================
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("✅ Student CRUD API is running!");
    }
}

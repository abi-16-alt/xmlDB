package com.existdb.student.repository;

import com.existdb.student.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import java.net.URI;
import java.util.*;

@Repository
public class StudentRepository {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${existdb.url}")
    private String existdbUrl;

    @Value("${existdb.collection}")
    private String collection;

    // ===================== CREATE =====================
    public Student save(Student student) {
        String fileName = "student_" + student.getId() + ".xml";
        String url = existdbUrl + collection + "/" + fileName;

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);

        String xmlBody = student.toXml();
        HttpEntity<String> request = new HttpEntity<>(xmlBody, headers);

        restTemplate.exchange(url, HttpMethod.PUT, request, String.class);
        System.out.println("✅ Saved: " + fileName);
        return student;
    }

    // ===================== READ ALL =====================
    public List<Student> findAll() {
        try {
            String xquery = "for $s in collection('/db/students')/student return $s";
            String encoded = java.net.URLEncoder.encode(xquery, "UTF-8");

            // Build URI manually to prevent double-encoding by RestTemplate
            String rawUrl = existdbUrl + collection + "?_query=" + encoded + "&_wrap=no";
            URI uri = new URI(rawUrl);

            System.out.println("🔍 Calling URI: " + uri);

            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_XML));
            HttpEntity<String> request = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(
                uri, HttpMethod.GET, request, String.class);

            String body = response.getBody();
            System.out.println("📥 Raw XML: " + body);
            return parseStudents(body);

        } catch (Exception e) {
            System.err.println("❌ Error fetching all students: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    // ===================== READ BY ID =====================
    public Optional<Student> findById(String id) {
        String fileName = "student_" + id + ".xml";
        String url = existdbUrl + collection + "/" + fileName;

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_XML));

        HttpEntity<String> request = new HttpEntity<>(headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(
                url, HttpMethod.GET, request, String.class);
            Student student = parseStudent(response.getBody());
            return Optional.ofNullable(student);
        } catch (Exception e) {
            System.err.println("❌ Student not found with id: " + id);
            return Optional.empty();
        }
    }

    // ===================== UPDATE =====================
    public Optional<Student> update(String id, Student updatedStudent) {
        Optional<Student> existing = findById(id);
        if (existing.isEmpty()) {
            return Optional.empty();
        }
        updatedStudent.setId(id);
        save(updatedStudent);
        System.out.println("✅ Updated student: " + id);
        return Optional.of(updatedStudent);
    }

    // ===================== DELETE =====================
    public boolean deleteById(String id) {
        String fileName = "student_" + id + ".xml";
        String url = existdbUrl + collection + "/" + fileName;

        try {
            restTemplate.delete(url);
            System.out.println("✅ Deleted student: " + id);
            return true;
        } catch (Exception e) {
            System.err.println("❌ Could not delete student: " + id);
            return false;
        }
    }

    // ===================== XML PARSING HELPERS =====================
    private List<Student> parseStudents(String xml) {
        List<Student> students = new ArrayList<>();
        if (xml == null || xml.isBlank()) return students;

        try {
            // Wrap in root element to handle multiple <student> elements
            String wrapped = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><root>" + xml.trim() + "</root>";

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Disable external entity processing for security
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new ByteArrayInputStream(wrapped.getBytes("UTF-8")));

            NodeList nodeList = doc.getElementsByTagName("student");
            System.out.println("📊 Found " + nodeList.getLength() + " student(s) in XML");

            for (int i = 0; i < nodeList.getLength(); i++) {
                Element el = (Element) nodeList.item(i);
                String id = getTagValue("id", el);
                String name = getTagValue("name", el);
                String department = getTagValue("department", el);
                String grade = getTagValue("grade", el);

                // Skip incomplete records (like test entries)
                if (id.isBlank() || name.isBlank()) continue;

                Student s = new Student();
                s.setId(id);
                s.setName(name);
                s.setDepartment(department);
                s.setGrade(grade);
                students.add(s);
            }
        } catch (Exception e) {
            System.err.println("❌ XML parse error: " + e.getMessage());
            e.printStackTrace();
        }
        return students;
    }

    private Student parseStudent(String xml) {
        if (xml == null || xml.isBlank()) return null;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new ByteArrayInputStream(xml.getBytes("UTF-8")));

            Element root = doc.getDocumentElement();
            Student s = new Student();
            s.setId(getTagValue("id", root));
            s.setName(getTagValue("name", root));
            s.setDepartment(getTagValue("department", root));
            s.setGrade(getTagValue("grade", root));
            return s;
        } catch (Exception e) {
            System.err.println("❌ XML parse error: " + e.getMessage());
            return null;
        }
    }

    private String getTagValue(String tag, Element element) {
        try {
            NodeList list = element.getElementsByTagName(tag);
            if (list.getLength() > 0) {
                return list.item(0).getTextContent().trim();
            }
        } catch (Exception e) { /* ignore */ }
        return "";
    }

    private String encodeQuery(String query) {
        try {
            return java.net.URLEncoder.encode(query, "UTF-8");
        } catch (Exception e) {
            return query;
        }
    }
}